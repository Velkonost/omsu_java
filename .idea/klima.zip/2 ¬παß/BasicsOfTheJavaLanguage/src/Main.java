import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        BasicsOfTheJavaLanguage current = new BasicsOfTheJavaLanguage();
        int number;
        do {
            System.out.print("Enter job number (or 0 for exit): ");
            number = in.nextInt();
            if (number == 1) {
                current.helloWorld();
            } else if (number == 2) {
                current.threeNumbers();
            } else if (number == 3) {
                current.threeNumbersModified();
            } else if (number == 4) {
                current.quadraticEquation();
            } else if (number == 5) {
                current.functionTabulation();
            } else if (number == 6) {
                current.linearEquation();
            } else if (number == 7) {
                System.out.printf("The value: %.6f", current.tailorSeries());
                System.out.println();
            }
        } while (number != 0);

    }
}
