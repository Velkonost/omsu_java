import java.util.Scanner;
public class BasicsOfTheJavaLanguage {
    //public static void main(String[] args) {}
    public static void helloWorld() {
        System.out.println("Hello, World!");
    }
    public static void threeNumbers() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter three numbers: ");
        double first = in.nextDouble();
        double second = in.nextDouble();
        double third = in.nextDouble();
        System.out.println("Multiplication: " + first*second*third);
        System.out.println("Arithmetic: " + (first+second+third)/3);
        if(first>=second && second>=third) {
            System.out.println(first + ", " + second + ", " + third);
        }
        else if(first>=third && third>=second) {
            System.out.println(first + ", " + third + ", " + second);
        }
        else if(second>=first && first>=third) {
            System.out.println(second + ", " + first + ", " + third);
        }
        else if(second>=third && third>=first) {
            System.out.println(second + ", " + third + ", " + first);
        }
        else if(third>=first && first>=second) {
            System.out.println(third + ", " + first + ", " + second);
        }
        else{
            System.out.println(third + ", " + second + ", " + first);
        }
    }
    public static void threeNumbersModified() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter three numbers: ");
        int first = in.nextInt();
        int second = in.nextInt();
        int third = in.nextInt();
        System.out.println("Multiplication: " + first*second*third);
        System.out.println("Arithmetic: " + (first+second+third)/3);
        if(first>=second && second>=third) {
            System.out.println(first + ", " + second + ", " + third);
        }
        else if(first>=third && third>=second) {
            System.out.println(first + ", " + third + ", " + second);
        }
        else if(second>=first && first>=third) {
            System.out.println(second + ", " + first + ", " + third);
        }
        else if(second>=third && third>=first) {
            System.out.println(second + ", " + third + ", " + first);
        }
        else if(third>=first && first>=second) {
            System.out.println(third + ", " + first + ", " + second);
        }
        else{
            System.out.println(third + ", " + second + ", " + first);
        }
    }
    public static void quadraticEquation(){
        double discriminant;
        Scanner in = new Scanner(System.in);
        System.out.print("Enter three numbers: ");
        double first = in.nextDouble();
        double second = in.nextDouble();
        double third = in.nextDouble();
        System.out.println("Quadratic Equation: " + first + "x^2" + " + " + second + "x" + " + " + third);
        discriminant = second*second - 4*first*third;
        if(first == 0){
            System.out.println("It is not quadratic equation");
        }
        else if(discriminant<0){
            System.out.println("No real roots");
        }
        else if(discriminant == 0){
            System.out.println("One root:" + (-1)*second/(2*first));
        }
        else {
            System.out.println("Two roots:" + ((-1)*second+Math.sqrt(discriminant))/(2*first) + " and " + ((-1)*second - Math.sqrt(discriminant))/(2*first));
        }
    }
    public static void functionTabulation(){
        Scanner in = new Scanner(System.in);
        System.out.println("Function: sin(x)");
        System.out.print("Enter the bounders of the tabulation: ");
        double left = in.nextDouble();
        double right = in.nextDouble();
        System.out.print("Enter the step of the tabulation: ");
        double step = in.nextDouble();
        for(double i = left; i < right || Math.abs(i - right) < 1e-9; i+= step){
            System.out.print("x: " + i + " ");
            System.out.println("sin(x): " + Math.sin(i));
        }
        System.out.println();
    }
    public static void linearEquation(){
        double determinant;
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the coefficients (before x and y and free) of first equation: ");
        double a1 = in.nextDouble();
        double b1 = in.nextDouble();
        double c1 = in.nextDouble();
        System.out.print("Enter the coefficients (before x and y and free) of second equation: ");
        double a2 = in.nextDouble();
        double b2 = in.nextDouble();
        double c2 = in.nextDouble();
        System.out.println("System of equations: ");
        System.out.println(a1 + "x + " + b1 + "y + " + c1 + " = 0" );
        System.out.println(a2 + "x + " + b2 + "y + " + c2 + " = 0" );
        determinant = a1*b2 - a2*b1;
        if(determinant==0) {
            if (a1 * c2 - a2 * c1 == 0) {
                System.out.println("Infinitely many solutions");
            }
            else {
                System.out.println("No solutions");
            }
        }
        else {
            System.out.println("x = " + (b1*c2 - b2*c1) / determinant);
            System.out.println("y = " + (a2*c1 - a1*c2) / determinant);
        }
    }
    public static double tailorSeries(){
        int factorial = 1;
        double currentValue = 1;
        double valuePrecision = 1;
        double result = 1;
        double xCurrent = 1;
        Scanner in = new Scanner(System.in);
        System.out.println("Function: exp(x)");
        System.out.print("Enter the value of x: ");
        double x = in.nextDouble();
        System.out.print("Enter the precision: ");
        double precision = in.nextDouble();
        for(int i = 1; valuePrecision >= precision; i++){
            currentValue = currentValue * x / i;
            valuePrecision = Math.abs(currentValue);
            result += currentValue;
        }
        return result;
    }
}