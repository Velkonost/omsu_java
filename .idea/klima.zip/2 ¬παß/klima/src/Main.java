public class Main {

    public static void main(String[] args) throws Exception  {
        Basics.sayHelloWorld();
        Basics.secondQuestion(1, 2, 5);
        return;
    }
}
