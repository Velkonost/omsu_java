import java.util.Scanner;

public class Func_Massive {
    void function_1(int a, int[] arr) {
        int[] array;
        int n;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter numbers of array: ");
        n = in.nextInt();
        array = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Enter a[" + i + "] = ");
            array[i] = in.nextInt();
        }
    }
    int function_2 (int[] arr){
        int[] array;
        int n;
       int sum=0;

                array = new int [n];
            for (int i = 0 ; i<n; i++){
                array[i] = in.nextInt();
                sum += array[i];
            }
           return sum;
    }
    void function_3(int a, int[] arr){
        int[] array;
        int n;
        Scanner in = new Scanner(System.in);
        int sum = 0;
            System.out.println("Enter numbers of array: ");
            n = in.nextInt();
            array = new int [n];
            for (int i = 0 ; i<n; i++){
                System.out.println("Enter a[" + i + "] = ");
                array[i] = in.nextInt();
                if( array[i]%2==0 ){
                    sum++;
                }
                else{}
            }
            System.out.println(" Quantity of even numbers = "+sum);
    }
    void function_4(int a, int[] arr){
        int[] array;
        int n;
        int a , b;
        int sum = 0;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter numbers of array: ");
        n = in.nextInt();
        System.out.println("Enter a: ");
        a = in.nextInt();
        System.out.println("Enter b: ");
        b = in.nextInt();
        array = new int [n];
        for (int i = 0 ; i<n; i++){
            System.out.println("Enter a[" + i + "] = ");
            array[i] = in.nextInt();
            if( array[i]>=a || array[i]<= b){
                sum++;
            }
            else{}
        }
        System.out.println(" Quantity of numbers wich standing beetwen [a;b] = "+sum);
    }

   void function_5(int a, int[] arr){
            int[] array;
            int n;
            int check = 0;
            Scanner in = new Scanner(System.in);
            System.out.println("Enter numbers of array: ");
            n = in.nextInt();
            array = new int [n];
            for (int i = 0 ; i<n; i++){
        System.out.println("Enter a[" + i + "] = ");
        array[i] = in.nextInt();
        if(array[i]<0){
        check = -1;
        }
        else{}
        }
        if(check == 0){
        System.out.println("Yes ");}
        else{
        System.out.println("No ");}
        }
    void function_6(int a, int[] arr){
            int[] array;
            int n;
            int g;
            int check = 0;
            Scanner in = new Scanner(System.in);
            System.out.println("Enter numbers of array: ");
            n = in.nextInt();
            array = new int [n];

            for (int i = 0; i < n; i++) {
        System.out.println("Enter a[" + i + "] = ");
        array[i] = in.nextInt();
        }
        System.out.println("Changed output order");
        for (g=n-1; g>=0; g--){
        System.out.println(+array[g]);
        }

    };
}
