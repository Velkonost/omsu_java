import java.util.Scanner;

public class Massive_3 {
    public static void main(String[] args) {
        int[] array;
        int n;
        int sum = 0;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter numbers of array: ");
        n = in.nextInt();
        array = new int [n];
        for (int i = 0 ; i<n; i++){
            System.out.println("Enter a[" + i + "] = ");
            array[i] = in.nextInt();
                if( array[i]%2==0 ){
                    sum++;
                }
                else{}
        }
        System.out.println(" Quantity of even numbers = "+sum);
    }
}

