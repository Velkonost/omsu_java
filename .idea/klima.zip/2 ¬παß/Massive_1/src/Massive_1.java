import java.util.Scanner;

public class Massive_1 {
    public static void main(String[] args) {
        int[] array;
        int n;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter numbers of array: ");
        n = in.nextInt();
        array = new int [n];
        for (int i = 0 ; i<n; i++){
            System.out.println("Enter a[" + i + "] = ");
            array[i] = in.nextInt();
        }

    }
}
