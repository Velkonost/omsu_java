import java.util.Scanner;

public class Massive_6 {
    public static void main(String[] args) {
        int[] array;
        int n;
        int g;
        int check = 0;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter numbers of array: ");
        n = in.nextInt();
        array = new int [n];

            for (int i = 0; i < n; i++) {
                System.out.println("Enter a[" + i + "] = ");
                array[i] = in.nextInt();
            }
        System.out.println("Changed output order");
            for (g=n-1; g>=0; g--){
                System.out.println(+array[g]);
            }

    }
}
