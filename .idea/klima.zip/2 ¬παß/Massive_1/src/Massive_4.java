import java.util.Scanner;

public class Massive_4 {
    public static void main(String[] args) {
        int[] array;
        int n;
        int a , b;
        int sum = 0;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter numbers of array: ");
        n = in.nextInt();
        System.out.println("Enter a: ");
        a = in.nextInt();
        System.out.println("Enter b: ");
        b = in.nextInt();
        array = new int [n];
        for (int i = 0 ; i<n; i++){
            System.out.println("Enter a[" + i + "] = ");
            array[i] = in.nextInt();
            if( array[i]>=a || array[i]<= b){
                sum++;
            }
            else{}
        }
        System.out.println(" Quantity of numbers wich standing beetwen [a;b] = "+sum);
    }
}
