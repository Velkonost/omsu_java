








public class Decart {

    public static void main(String[] args) {

    }



}
