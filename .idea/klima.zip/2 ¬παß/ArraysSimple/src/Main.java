import java.util.Random;

public class Main {

    public static void main(String[] args) throws Exception
    {
        //Basics.BasicQuest2();//done
        //Basics.BasicQuest3();//done
        //Basics.BasicQuest4();//done
        //Basics.BasicQuest5();//done
        //Basics.BasicQuest6();//done
        //Basics.BasicQuest7();


/*
        int myArray[];
        myArray = ArraysCreator.enterArray();
        ArraysCreator.ArraySimple1(myArray);//done
        ArraysCreator.ArraySimple3(myArray);//done
        ArraysCreator.ArraySimple4(myArray);//done
        ArraysCreator.ArraySimple5(myArray);//done
        ArraysCreator.ArraySimple6(myArray);//done
        ArraysCreator.ArraySimple7(myArray);//done
        */


        //Отсюда идёт Point3D

        Point3D point1 = new Point3D();
        //System.out.println("Конструктор без параметров");
        System.out.println(point1.toString());
       // System.out.println("Конструктор с параметрами");
        Point3D point = new Point3D(10,10,10);
        System.out.println(point.toString());
        point.setX(5);
        point.setY(5);
        point.setZ(5);
        System.out.println("Точка с изменёнными значениями");
        System.out.println(point.toString());
        System.out.println(point.getX());
        System.out.println(point.getY());
        System.out.println(point.getZ());
        System.out.print(point.toString() + " " + point1.toString());
        System.out.println("\nСравнение двух данных точек");
        if (point.equals(point1))
        {
            System.out.println("Они равны");
        }
        else
        {
            System.out.println("Они не равны");
        }
        System.out.print(point.toString() + " " + point.toString());
        System.out.println("\nСравнение точки с самой собой");
        if (point.equals(point))
        {
            System.out.println("Они равны");
        }
        else
        {
            System.out.println("Они не равны");
        }



        //Отсюда идёт Vector3D

        Vector3D vector = new Vector3D();
        System.out.println("Конструктор без параметров");
        System.out.println(vector.toString());
        System.out.println("Конструктор с параметрами");
        Vector3D vector1 = new Vector3D(3,6,9);
        System.out.println(vector1.toString());
        System.out.println("Конструктор по координатам точки");
        Vector3D vector2 = new Vector3D(point1, point);
        System.out.println(vector2.toString());
        double length = vector2.lengthCalculation();
        System.out.println("Длина последнего вектора равна");
        System.out.println(length);
        System.out.printf(vector1.toString() + " " + vector2.toString());
        System.out.println("\nСравнение двух данных векторов");
        if (vector1.equals(vector2))
        {
            System.out.println("Они равны");
        }
        else
        {
            System.out.println("Они не равны");
        }

        //Отсюда идёт Vector3DProcessor
        System.out.println(Vector3DProcessor.sumOfVectors(vector1, vector2));
        System.out.println(Vector3DProcessor.differenceOfVectors(vector1, vector2));
        System.out.println(Vector3DProcessor.scalarMultiplication(vector1,vector2));
        System.out.println(Vector3DProcessor.vectorMultiplication(vector1,vector2));
        Vector3DProcessor.checkVectors(vector1,vector2);

        //Отсюда идёт Vector3DArray
        int size = 5;
        Vector3DArray array = new Vector3DArray(size);
        System.out.println("Размер данного массива = " + array.myArrayLength());
        array.change(vector1,2);
        array.change(vector2,3);
        System.out.println(array.maxLength());
        System.out.println("Результат первого вхождения vector1 = " + array.search(vector1));
        Vector3D vector3 = array.sumOfVectorsArray();
        System.out.println("Сумма всех векторов в массиве = " + vector3);
        double numbers[] = new double[size];
        for (int i=0; i<5;i++){
            numbers[i] = Math.random()%10;
        }
        Vector3D vector4 = array.linCombination(numbers);
        System.out.println("Линейная комбинация векторов = " + vector4);
        Point3D [] points;
        points = array.shiftP(point);
        for (int i =0; i<points.length;i++) {
            System.out.println(points[i]);
        }
    }



}
