
import java.util.Scanner;

public class ArraysCreator
    {

        public static int[] enterArray()
        {
            System.out.println("Введите количество элементов в массиве, который будет рассмотрен нами");
            Scanner s = new Scanner(System.in);
            int n;
            n = s.nextInt();
            int myArray[] = new int[n];
            for (int i = 0; i<n; i++)
            {
                System.out.printf("Введите значение %d элемента\n", i);
                myArray[i] = s.nextInt();
            }
            return myArray;
        }

        public static void printArray(int array[])
        {
            for (int i = 0; i<array.length; i++)
            {
                System.out.print(array[i]);
                System.out.print(" ");
            }
            System.out.printf("\n");
        }

        public static void ArraySimple1(int array[])
        {
            System.out.println("Вывод элементов массива на экран");
            printArray(array);
        }

        public static void ArraySimple3(int array[])
        {
            System.out.println("Сумма всех элементов массива");
            int sum = 0;
            for (int i = 0; i<array.length; i++)
            {
                sum = sum + array[i];
            }
            System.out.printf("Сумма элементов в массиве равна %d\n", sum);
        }
        public static void ArraySimple4(int array[])
        {
            System.out.println("Количество четных чисел в массиве");
            int checkPerem = 0;
            for (int i = 0; i<array.length; i++)
            {
                if (array[i] % 2 == 0)
                {
                    checkPerem++;
                }
            }
            System.out.printf("Количество чётных чисел в массиве = %d\n", checkPerem);
        }
        public static void ArraySimple5(int array[])
        {
            System.out.println("Количество элементов массива, принадлежащих отрезку [a; b]");
            Scanner s = new Scanner(System.in);
            int a,b;
            System.out.println("Введите границы отрезка");
            a = s.nextInt();
            b = s.nextInt();
            int checkPerem = 0;
            for (int i = 0; i<array.length; i++)
            {
                if (array[i]>=a && array[i]<=b)
                {
                    checkPerem++;
                }
            }
            System.out.printf("Количество элементов массива принадлежащих отрезку [a; b] = %d\n", checkPerem);
        }
        public static void ArraySimple6(int array[])
        {
            System.out.println("Проверка: все ли элементы массива положительные");
            int checkPerem = 0;
                for (int i = 0; i<array.length && checkPerem ==0; i++)
                {
                    if (array[i] <= 0)
                    {
                        checkPerem = 1;
                    }
                }
            if (checkPerem == 1)
            {
                System.out.printf("Нет, не все элементы в массиве положительны\n");
            }
            else
            {
                System.out.printf("Да, все элементы в массиве положительны\n");
            }
        }
        public static void ArraySimple7(int array[])
        {
            System.out.println("Переставьте в массиве элементы в обратном порядке");
            int i;
            System.out.printf("");
            i = 0;
            int j = array.length - 1;
            int tmp;
            while (j > i)
            {
                tmp = array[j];
                array[j] = array[i];
                array[i] = tmp;
                j--;
                i++;
            }
            for (i = 0; i<array.length; i++)
            {
                System.out.print(array[i]);
                System.out.print(" ");
            }
        }
    }