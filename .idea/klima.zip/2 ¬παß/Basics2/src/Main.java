import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        //String string1 = StringProcessor.stringEnter();
        Scanner s = new Scanner(System.in);

        /*
        //Задание номер 1: Печать N раз введённой строки

        System.out.println("Введите число N");
        int N = s.nextInt();
        String stringOut = StringProcessor.stringPrint(string1, N);
        System.out.println(stringOut);

        //Задание номер 2: Поиск количества вхождений второй строки в первую

        String string2 = StringProcessor.stringEnter();
        N = StringProcessor.stringInclude(string1, string2);
        System.out.println("Количество вхождений второй строки в первую\n" + N);

        //Задание номер 3: Построение новой строки с заменой 1.2.3 на буквенный эквивалент

        stringOut = StringProcessor.stringChange(string1);
        System.out.println("Строка, с изменёнными 1.2.3 символами\n" +stringOut);

        //Задание номер 4: Удаление каждого второго символа из строки

        StringBuilder stringInOutBuilder = new StringBuilder(string1);
        stringInOutBuilder = StringProcessor.stringBuilderDeleteEverySecondSymbol(stringInOutBuilder);
        System.out.println("Строка, с удалёнными символами (каждый второй символ)\n" + stringInOutBuilder.toString());
        */

        //Задание номер 5: Поменять местами первое и последнее слова

        String string3 = StringProcessor.stringEnter();
        StringBuilder stringChangeFirstLastWords = new StringBuilder(string3);
        stringChangeFirstLastWords = StringProcessor.stringBuilderChangeFirstLast(stringChangeFirstLastWords);
        System.out.println("Строка, в которой поменяли местами первое и последнее слова\n" + stringChangeFirstLastWords.toString());

        //Задание номер 6: Построить новую строку, в которой шестнадцатеричные числа будут заменены на десятичные эквиваленты
        String string4 = StringProcessor.stringEnter();
        string4 = StringProcessor.change16NumbersTo10InString(string4);
        System.out.println("Строка с переведёнными данными\n" + string4);

    }
}
