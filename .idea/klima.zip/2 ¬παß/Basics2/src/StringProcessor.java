import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringProcessor {
    public static String stringEnter() {
        System.out.println("Введите новую строку");
        Scanner s = new Scanner(System.in);
        String str;
        str = s.nextLine();
        return str;
    }

    public static String stringPrint(String s, int N) {
        System.out.println("Печать N раз введённой строки");
        if (N < 0) {
            return "ERROR";
        }
        if (N == 0) {
            return "";
        }
        StringBuilder stringOut = new StringBuilder();
        for (int i = 0; i < N; i++) {
            stringOut.append(s);
        }
        return stringOut.toString();
    }

    public static int stringInclude(String string1, String string2) {
        StringBuilder stringHelper = new StringBuilder(string1);
        int n = 0;

        while (stringHelper.indexOf(string2) != -1) {
            n++;
            int checker = stringHelper.indexOf(string2);
            stringHelper.delete(checker, checker + string2.length());
        }
        return n;
    }

    public static String stringChange(String string1) {
        StringBuilder stringOut = new StringBuilder();
        stringOut.append(string1);
        for (int i = 0; i < stringOut.length(); i++) {
            if (stringOut.charAt(i) == '1') {
                stringOut.replace(i, i + 1, "один");
            }
            if (stringOut.charAt(i) == '2') {
                stringOut.replace(i, i + 1, "два");
            }
            if (stringOut.charAt(i) == '3') {
                stringOut.replace(i, i + 1, "три");
            }
        }
        return stringOut.toString();
    }

    public static StringBuilder stringBuilderDeleteEverySecondSymbol(StringBuilder stringInOutBuilder) {
        for (int i = 1; i < stringInOutBuilder.length(); i++) {
            stringInOutBuilder.deleteCharAt(i);
        }
        return stringInOutBuilder;
    }

    public static StringBuilder stringBuilderChangeFirstLast(StringBuilder mainString) {
        if (mainString.length() == 0) {
            return mainString;
        }
        int value = 0, value2 = 0;
        int i = 0;
        StringBuilder stringOut = new StringBuilder(mainString);
        while (i<mainString.length() && mainString.charAt(i) == ' ') {
            value++;
            i++;
        }
        if (value == mainString.length()) {
            return stringOut;
        }
        mainString.delete(0, value);
        if (mainString.indexOf(" ") == -1) {
            return stringOut;
        }
        String firstWord = mainString.substring(0, mainString.indexOf(" "));
        mainString.delete(0, firstWord.length());
        i = mainString.length();
        while (i >= 1 && mainString.charAt(i - 1) == ' ') {
            value2++;
            i--;
        }
        mainString.delete(mainString.length() - value2, mainString.length());
        String lastWord = mainString.substring(mainString.lastIndexOf(" ") + 1, mainString.length());
        mainString.delete(mainString.length() - lastWord.length(), mainString.length());
        stringOut.delete(0, stringOut.length());
        for (int j = 0; j < value; j++) {
            stringOut.append(" ");
        }
        stringOut.append(lastWord);
        stringOut.append(mainString);
        stringOut.append(firstWord);
        for (int j = 0; j < value2; j++) {
            stringOut.append(" ");
        }
        return stringOut;
    }

    public static String change16NumbersTo10InString(String obj) throws IllegalArgumentException {
        if (obj.isEmpty()) {
            throw new IllegalArgumentException("Строка не была введена");
        }
        StringBuilder res = new StringBuilder(obj);
        StringBuilder res2 = new StringBuilder();
        String str;
        int value = 0;
        int x;
        Pattern hex = Pattern.compile("0х[0123456789abcdefABCDEF]+|0x[0123456789abcdefABCDEF]+");
        Matcher finder = hex.matcher(res);
        while (finder.find()) {
            res2.append(res.substring(value, finder.start()));
            x = Integer.parseInt(res.substring(finder.start() + 2, finder.end()), 16);
            str = Integer.toString(x);
            res2.append(str);
            value = finder.end();
        }
        res2.append(res.substring(value));
        return res2.toString();
    }
}
