/*(1 задание) public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}*/
/*(2 задание)public class Main {
    public static void ella(){
        float a=12;
        float b=14;
        float c=2;
        float temp;
        System.out.println(a*b*c);
        System.out.println((a+b+c)/3);
        if (a>b){temp=b;b=a;a=temp;}
        if (b>c){temp=c;c=b;b=temp;}
        if (a>b){temp=b;b=a;a=temp;}
        System.out.printf("%f\n%f\n%f\n",a,b,c);
    }

    (3 задание) public static void who(){
        int a=5;
        int b=1;
        int c=2;
        int temp;
        System.out.println(a*b*c);
        System.out.println((a+b+c)/3.0);
        if (a>b){temp=b;b=a;a=temp;}
        if (b>c){temp=c;c=b;b=temp;}
        if (a>b){temp=b;b=a;a=temp;}
        System.out.printf("%d\n%d\n%d\n",a,b,c);
    }

    public static void main(String[]args) {
        ella();
        who();
    }
}*/
/*(4 задание)public class Main {
    public static void main(String[] args) {
    double a = 2;
    double b = 9;
    double c = 4;
    double di;
    double x1;
    double x2;
    di = (b*b) -(4*a*c);
        if (di>0){
        x1 = ((-1) * b + Math.sqrt(di)) / (2 * a);
        x2 = ((-1) * b - Math.sqrt(di)) / (2 * a);
            System.out.printf("x1 = " + x1 +  " x2 = " + x2);
        }
        else if (di == 0){
            x1 = (-1) * b;
            System.out.printf("x1, x2 = " + x1);
        }
        else
            System.out.print("Корней нет. Дискриминант меньше нуля");
    }


}*/
import static java.lang.Math.*;
public class Main {
    public static void main(String[] args) {
    double x1,x2,step,temp;
    if (x1>x2){

        temp=x2;
        x2=x1;
        x1=temp;
    }

    sin(x);



