public class Main {

    public static void main(String[] args) throws Exception {
        System.out.println("Hello World!");
        Basics.BasicQuest2();
        Basics.BasicQuest3();
        Basics.BasicQuest4();
        Basics.BasicQuest5();
        Basics.BasicQuest6();
        Basics.BasicQuest7();
    }
}

