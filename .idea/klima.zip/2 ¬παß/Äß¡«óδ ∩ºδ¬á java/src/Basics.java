import java.io.PrintStream;
import java.math.BigDecimal;
import java.util.Scanner;

import static java.lang.Math.incrementExact;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import static java.lang.StrictMath.sin;

public class Basics {
    public static double BasicQuest2() {
        System.out.println("Задача с вещественными числами\nВведите вещественные значения трёх переменных");
        double a;
        double b;
        double c;
        double buff;
        Scanner s = new Scanner(System.in);
        a = s.nextDouble();
        b = s.nextDouble();
        c = s.nextDouble();
        double mult = a * b * c;
        double average = (a + b + c) / 3;
        for (int i = 0; i < 2; i++) {
            if (b < a) {
                buff = a;
                a = b;
                b = buff;
            }
            if (c < b) {
                buff = b;
                b = c;
                c = buff;
            }
        }
        System.out.println(mult);
        System.out.println(average);
        System.out.printf("%f, %f, %f\n", a, b, c);
        return 0;
    }

    public static int BasicQuest3() {
        System.out.println("Задача с целыми числами\nВведите целые значения трёх переменных");
        int a;
        int b;
        int c;
        int buff;
        Scanner s = new Scanner(System.in);
        a = s.nextInt();
        b = s.nextInt();
        c = s.nextInt();
        int mult = a * b * c;
        double average = (a + b + c) / 3.0;
        for (int i = 0; i < 2; i++) {
            if (b < a) {
                buff = a;
                a = b;
                b = buff;
            }
            if (c < b) {
                buff = b;
                b = c;
                c = buff;
            }
        }
        System.out.println(mult);
        System.out.printf("%f\n", average);
        System.out.printf("%d, %d, %d\n", a, b, c);
        return 0;
    }

    public static double BasicQuest4() {
        System.out.println("Задача с вещественными значениями коэффициентов квадратного уравнения\nВведите вещественные значения трёх переменных");
        double a;
        double b;
        double c;
        double D;
        Scanner s = new Scanner(System.in);
        a = s.nextDouble();
        b = s.nextDouble();
        c = s.nextDouble();
        D = b * b - 4 * a * c;
        if (D < 0) {
            System.out.println("Корней нет");
        } else if (D == 0) {
            System.out.println("Решение есть\nОтвет\n");
            double res = -b / (2 * a);
            System.out.printf("%f\n", res);
        } else if (D > 0 && a != 0) {
            System.out.println("Решение есть\nОтвет\n");
            double res1 = -b - sqrt(D) / (2 * a);
            double res2 = -b + sqrt(D) / (2 * a);
            System.out.printf("%f, %f\n", res1, res2);
        } else {
            System.out.println("Решение есть\nОтвет\n");
            double res1 = -c / b;
            System.out.printf("%f\n", res1);
        }
        return 0;
    }

    public static double BasicQuest5() {
        System.out.println("Табулирование функции sin(x)\nВведите границы табулирования");
        double a;
        double b;
        double step;
        double result;
        Scanner s = new Scanner(System.in);
        a = s.nextDouble();
        b = s.nextDouble();
        System.out.println("Введите шаг\n");
        step = s.nextDouble();
        while (Math.abs(a - b) < 1e-9 || a < b) {
            System.out.printf("%f - ", a);
            result = sin(a);
            System.out.println(result);
            a = a + step;
        }
        return 0;
    }

    public static double BasicQuest6() {
        Scanner s = new Scanner(System.in);
        System.out.println("Программа для решения СЛУ\nax+by=c, dx+ey=f");
        System.out.println("Введите необходимые значения a,b,c для первого уравнения");
        double a, b, c;
        a = s.nextDouble();
        b = s.nextDouble();
        c = s.nextDouble();
        System.out.println("Введите необходимые значения d,e,f для второго уравнения");
        double d, e, f;
        d = s.nextDouble();
        e = s.nextDouble();
        f = s.nextDouble();
        double determinatemain;
        double determinate1;
        double determinate2;
        double result1;
        double result2;
        determinatemain = a * e - b * d;
        determinate1 = c * e - b * f;
        determinate2 = a * f - c * d;
        if (determinatemain == 0 && determinate1 != 0 && determinate2 != 0) {
            System.out.println("Система решений не имеет\n");
        } else if (determinatemain == 0 && determinate1 == 0 && determinate2 == 0) {
            System.out.println("Решений бесконечное количество\n");
        } else if (determinatemain != 0) {
            result1 = determinate1 / determinatemain;
            result2 = determinate2 / determinatemain;
            System.out.printf("x = %f, y = %f", result1, result2);
        }
        return 0;
    }

    public static double BasicQuest7() {
        Scanner s = new Scanner(System.in);
        double x, accuracy;
        System.out.println("\nРазложение в ряд Тейлора функции e^x\nВведите значение х");
        x = s.nextDouble();
        System.out.println("Введите точность вычисления");
        accuracy = s.nextDouble();
        double i = 1;
        double sum = 1;
        double nextsum = x;
        System.out.printf("%f\n", sum);
        while (nextsum > accuracy) {
            i++;
            sum = sum + nextsum;
            nextsum = nextsum * x / i;
            System.out.println(sum);
        }
        return 0;
    }
}